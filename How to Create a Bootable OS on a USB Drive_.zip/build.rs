use std::path::PathBuf;

fn main() {
    let out_dir = PathBuf::from(std::env::var_os("OUT_DIR").expect("Cargo did not provide OUT_DIR"));
    let kernel = PathBuf::from(
        std::env::var_os("CARGO_BIN_FILE_KERNEL_kernel")
            .expect("kernel artifact was not built; use nightly Cargo with bindeps enabled"),
    );

    let uefi_path = out_dir.join("aurora-vault-uefi.img");
    bootloader::UefiBoot::new(&kernel)
        .create_disk_image(&uefi_path)
        .expect("failed to create UEFI disk image");

    let bios_path = out_dir.join("aurora-vault-bios.img");
    bootloader::BiosBoot::new(&kernel)
        .create_disk_image(&bios_path)
        .expect("failed to create BIOS disk image");

    println!("cargo:rustc-env=AURORA_UEFI_IMAGE={}", uefi_path.display());
    println!("cargo:rustc-env=AURORA_BIOS_IMAGE={}", bios_path.display());
    println!("cargo:rerun-if-changed=kernel/src/main.rs");
}
