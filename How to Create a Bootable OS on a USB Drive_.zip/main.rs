use std::env;
use std::path::PathBuf;

fn main() {
    let mode = env::args().nth(1).unwrap_or_else(|| "info".to_string());
    let uefi = PathBuf::from(env!("AURORA_UEFI_IMAGE"));
    let bios = PathBuf::from(env!("AURORA_BIOS_IMAGE"));

    match mode.as_str() {
        "info" => {
            println!("Aurora Vault OS build complete.");
            println!("UEFI image: {}", uefi.display());
            println!("BIOS image: {}", bios.display());
            println!();
            println!("Run `cargo run -- uefi` or `cargo run -- bios` after installing QEMU.");
            println!("For a physical USB, use scripts/write-usb.sh with the correct device path.");
        }
        "uefi" => launch_qemu(&uefi, true),
        "bios" => launch_qemu(&bios, false),
        _ => {
            eprintln!("Usage: cargo run -- [info|uefi|bios]");
            std::process::exit(2);
        }
    }
}

fn launch_qemu(image: &PathBuf, uefi: bool) {
    let mut command = std::process::Command::new("qemu-system-x86_64");
    command.args(["-m", "512M", "-serial", "stdio"]);
    if uefi {
        let code = std::env::var("OVMF_CODE").unwrap_or_else(|_| "/usr/share/edk2/x64/OVMF_CODE.fd".into());
        let vars = std::env::var("OVMF_VARS").unwrap_or_else(|_| "/usr/share/edk2/x64/OVMF_VARS.fd".into());
        command.args(["-drive", &format!("if=pflash,format=raw,readonly=on,file={code}"), "-drive", &format!("if=pflash,format=raw,file={vars}")]);
    }
    let status = command.args(["-drive", &format!("format=raw,file={}", image.display())]).status();
    match status {
        Ok(status) => std::process::exit(status.code().unwrap_or(1)),
        Err(error) => {
            eprintln!("Could not start QEMU: {error}");
            eprintln!("Install qemu-system-x86_64 and, for UEFI, edk2/OVMF.");
            std::process::exit(1);
        }
    }
}
